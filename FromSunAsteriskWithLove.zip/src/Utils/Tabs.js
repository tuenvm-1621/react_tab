import React, { useState, useEffect } from 'react';

import Tab from './Tab';

export default props => {
  const { children, setTabName, setTabs, tabs, tabName } = props;
  const [activeTab, setActiveTab] = useState(children[0].props.label);
  const currentIndex = tabs.findIndex(tab => tab.label === activeTab);
  const onClickTabItem = tab => {
    setActiveTab(tab);
  };
  const handleNewTab = () => {
    debugger;
    setTabName(tabName + 1);
    setTabs([...tabs, { label: tabName }]);
    setActiveTab(tabName);
  };
  const onCloseTab = closeTab => {
    setTabs(tabs.filter(tab => tab.label !== closeTab), () => {
      if (tabs.length === 0) {
        // handleNewTab();
        debugger;
      }
    });
    debugger;
    if (closeTab === activeTab) {
      if (currentIndex === 0) {
        if (tabs.length === 1) {
          debugger;
          handleNewTab();
        }
        tabs.length > 1 && setActiveTab(tabs[currentIndex + 1].label);
      } else {
        setActiveTab(tabs[currentIndex - 1].label);
      }
    }
  };

  useEffect(() => {}, [activeTab, tabs]);
  return (
    <div>
      <ol className='tab-list'>
        {children.map(child => {
          if (child) {
            const { label } = child.props;
            return (
              <Tab
                activeTab={activeTab}
                key={label}
                label={label}
                onClickTabItem={onClickTabItem}
                onCloseTab={onCloseTab}
              />
            );
          }
          return null;
        })}
        <li className='plus-tab' onClick={handleNewTab}>
          +
        </li>
      </ol>
      <div className='tab-content'>
        {children.map(child => {
          if (!child || child.props.label !== activeTab) return undefined;
          return child.props.children;
        })}
      </div>
    </div>
  );
};
