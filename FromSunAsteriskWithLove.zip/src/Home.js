import React, { useState } from 'react';
import { render } from 'react-dom';

import Tabs from './Utils/Tabs';
import NewTab from './NewTab';

import './css/Tab.css';
const container = document.createElement('div');

document.body.appendChild(container);
const Home = () => {
  const [tabs, setTabs] = useState([{ label: 0 }]);
  const [tabName, setTabName] = useState(1);
  return (
    <Tabs {...{ tabs, setTabs, tabName, setTabName }}>
      {tabs.length !== 0 &&
        tabs.map(child => (
          <div key={child.label} label={child.label}>
            {render(<NewTab />, container)}
          </div>
        ))}
    </Tabs>
  );
};

export default Home;
