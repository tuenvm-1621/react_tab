import React, { useState } from 'react';

export default () => {
  const [count, setCount] = useState(0);
  return (
    <div>
      <h1>HomePage</h1>
      <a href='/' target='_blank'>
        Click to open new tab
      </a>
      <hr />
      <button onClick={() => setCount(count + 1)}>Click Me</button>
      <h3>{count}</h3>
      <hr />
    </div>
  );
};
